from exnovaapi.http.resource import Resource


class Profile(Resource):
    url = "profile"
