from exnovaapi.http.resource import Resource


class Billing(Resource):
    url = "billing"
