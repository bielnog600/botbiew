"""Module for API websocket objects."""
