"""Module for API websocket received."""
