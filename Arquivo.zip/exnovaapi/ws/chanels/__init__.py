"""Module for  API websocket chanels."""
